//
//  ArenaSquirtleViewController.swift
//  Pokemon3.1 iOS
//
//  Created by Manuel Manteiga on 27/01/2022.
//

import UIKit

class ArenaSquirtleViewController: UIViewController {
    
    @IBAction func arenatosquirtle(_ sender: Any) {
        self.performSegue(withIdentifier: "arenatosquirtle", sender: self)
    }
    
    //Imagens Random para oponente
    @IBOutlet weak var imagemRandom: UIImageView!
    var imagens = ["PokemonCharmander", "PokemonMew", "PokemonBarbasaur", "PokemonPikachu"]
    
    @IBAction func changebtn(_ sender: UIButton) {
        imagemRandom.image = UIImage(named: imagens.randomElement()!)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
