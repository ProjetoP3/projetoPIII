//
//  ArenaViewController.swift
//  Pokemon3.1 iOS
//
//  Created by Manuel Manteiga on 13/01/2022.
//

import UIKit
import SwiftUI

class ArenaCharmanderViewController: UIViewController {
    
    
    @IBAction func arenatocharmander(_ sender: Any) {
        self.performSegue(withIdentifier: "arenatocharmander", sender: self)
    }

    
    
    //Imagens Random para oponente
    @IBOutlet weak var imagensRandom: UIImageView!
    
    
    var images = ["PokemonMew","PokemonBarbasaur", "PokemonSquirtle", "PokemonPikachu"]
    @IBAction func btnChange(_ sender: UIButton) {
        imagensRandom.image = UIImage(named: images.randomElement()!)
    }
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
