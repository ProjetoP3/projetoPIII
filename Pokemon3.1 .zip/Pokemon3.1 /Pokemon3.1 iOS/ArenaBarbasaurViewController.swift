//
//  ArenaBarbasaurViewController.swift
//  Pokemon3.1 iOS
//
//  Created by Manuel Manteiga on 27/01/2022.
//

import UIKit

class ArenaBarbasaurViewController: UIViewController {
    
    @IBAction func arenatobarbasaur(_ sender: Any) {
        self.performSegue(withIdentifier: "arenatobarbasaur", sender: self)
    }
    
    
    //Imagens Random para oponente
    @IBOutlet weak var imagensRandom: UIImageView!
    
    var imagens = ["PokemonCharmander", "PokemonMew", "PokemonSquirtle", "PokemonPikachu"]
    @IBAction func changebtn(_ sender: Any) {
        imagensRandom.image = UIImage(named: imagens.randomElement()!)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
