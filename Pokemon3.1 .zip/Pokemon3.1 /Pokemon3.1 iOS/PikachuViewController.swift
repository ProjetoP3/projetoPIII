//
//  PikachuViewController.swift
//  Pokemon3.1 iOS
//
//  Created by Manuel Manteiga on 14/01/2022.
//

import UIKit

class PikachuViewController: UIViewController {
    
    @IBAction func pikatutosquirtle(_ sender: Any) {
        self.performSegue(withIdentifier: "pikatutosquirtle", sender: self)
    }
    @IBAction func pikachutoarena(_ sender: Any) {
        self.performSegue(withIdentifier: "pikachutoarena", sender: self)
    }
    
    @IBAction func pikachutocharmander(_ sender: Any) {
        self.performSegue(withIdentifier: "pikachutocharmander", sender: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
