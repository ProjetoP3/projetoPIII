import SwiftUI

struct PokemonImage: View {
    private let pokemon: Pokemon
    
    init(of pokemon: Pokemon) {
        self.pokemon = pokemon
    }
    var body: some View {
        Image(pokemon.img)
            .resizable()
            .scaledToFit()
            .frame(width: pokemon.pokemonWidth, height: pokemon.pokemonWidth)
            .modifier(Shake(animatableData: CGFloat(pokemon.hpStatus.attempts)))
            .animation(.easeOut(duration: 1.0), value: pokemon.hpStatus.hpLevel)
    }
}
