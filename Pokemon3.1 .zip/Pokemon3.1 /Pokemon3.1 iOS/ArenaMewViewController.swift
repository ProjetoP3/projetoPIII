//
//  ArenaMewViewController.swift
//  Pokemon3.1 iOS
//
//  Created by Manuel Manteiga on 27/01/2022.
//

import UIKit


class ArenaMewViewController: UIViewController {
    
    @IBAction func arenatomew(_ sender: Any) {
        self.performSegue(withIdentifier: "arenatomew", sender: self)
    }
    
    
    //Imagens Random para oponente
    @IBOutlet weak var imagensRandom: UIImageView!
    
    var images = ["PokemonCharmander", "PokemonBarbasaur", "PokemonSquirtle", "PokemonPikachu"]
    @IBAction func btnchange(_ sender: UIButton) {
        imagensRandom.image = UIImage(named: images.randomElement()!)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
