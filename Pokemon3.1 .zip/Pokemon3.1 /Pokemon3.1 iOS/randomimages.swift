//
//  randomimages.swift
//  Pokemon3.1 iOS
//
//  Created by Manuel Manteiga on 27/01/2022.
//

import UIKit

class randomimages: UIViewController {

    @IBOutlet UIImageView *imageView;
    
}


-(IBAction)randomi
