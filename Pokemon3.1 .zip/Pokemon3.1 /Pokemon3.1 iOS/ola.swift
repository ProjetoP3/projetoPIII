//
//  ola.swift
//  Pokemon3.1 iOS
//
//  Created by Manuel Manteiga on 14/01/2022.
//

import UIKit

class ola: UIViewController {
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("View has loaded :)")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
