import SwiftUI

struct MyPokemonView: View {
    var pokemon: Pokemon
    
    init(pokemon: Pokemon){
        self.pokemon = pokemon
    }
    var body: some View {
        HStack(alignment: .top) {
            PokemonImage(of: pokemon)
            PokemonStatsView(of: pokemon, isOpponent: false)
        }
        .animation(.easeOut(duration: 1.0))
        .position(x: pokemon.position, y: 100.0)
    }
}
