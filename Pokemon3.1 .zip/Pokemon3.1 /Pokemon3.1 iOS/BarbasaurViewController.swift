//
//  BarbasaurViewController.swift
//  Pokemon3.1 iOS
//
//  Created by Manuel Manteiga on 13/01/2022.
//

import UIKit

class BarbasaurViewController : UIViewController {
    
    @IBAction func barbasaurtomew(_ sender: Any) {
        self.performSegue(withIdentifier: "barbasaurtomew", sender: self)
    }
    
    @IBAction func barbasaurtoarena(_ sender: Any) {
        self.performSegue(withIdentifier: "barbasaurtoarena", sender: self)
    }
    
    
    @IBAction func barbasaurtosquirtle(_ sender: Any) {
        self.performSegue(withIdentifier: "barbasaurtosquirtle", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}

