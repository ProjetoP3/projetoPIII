//
//  HPBarView.swift
//  Pokemon3.1 iOS
//
//  Created by Manuel Manteiga on 29/01/2022.
//

import SwiftUI

struct HPBarView: View {
    var hpStatus: HPStatus
    
    init(hpStatus: HPStatus) {
        self.hpStatus = hpStatus
    }
    
    var body: some View {
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .frame(width: 150, height: 10)
                .foregroundColor(.black.opacity(0.1))
                .background()
            Rectangle()
                
                .frame(width: hpStatus.hpLevel, height: 10)
                .foregroundColor(hpStatus.hpColor)
                .animation(Animation.easeOut(duration: 1.0), value: hpStatus.hpLevel)
        }
    }
}
