//
//  SquirtleViewController.swift
//  Pokemon3.1 iOS
//
//  Created by Manuel Manteiga on 13/01/2022.
//

import UIKit

class SquirtleViewController: UIViewController {

    
    @IBAction func squirtletobarbasaur(_ sender: Any) {
        self.performSegue(withIdentifier: "squirtletobarbasaur", sender: self)
    }
    
    @IBAction func squirtletoarena(_ sender: Any) {
        self.performSegue(withIdentifier: "squirtletoarena", sender: self)
    }
    
    @IBAction func squirtletopikachu(_ sender: Any) {
        self.performSegue(withIdentifier: "squirtletopikachu", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //Mudar cor horas e bateria para branco
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
